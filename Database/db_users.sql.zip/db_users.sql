--
-- Database: `db_users`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstName` varchar(10) NOT NULL,
  `lastName` varchar(10) NOT NULL,
  `TimeofLogin` timestamp(5) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `password`, `firstName`, `lastName`, `TimeofLogin`) VALUES
(1, 'abc', '6367c48dd193d56ea7b0baad25b19455e529f5ee', 'Leslie', 'Chandler', '2018-10-04 04:08:48.55532'),
(2, 'xyz@gmail.com', '2b743ea5699560665032496d957cd8c0075029d5', 'Aditya', 'Malireddy', '2018-09-29 04:31:50.00000'),
(3, 'abcdef@gmail.com', 'abc1def23', 'Srikar', 'Karthik', '2018-09-28 05:00:00.00000'),
(4, 'pravalika@gmail.com', 'c9b359951c09c5d04de4f852746671ab2b2d0994', 'Pravalika', 'kawali', '2018-10-04 03:50:33.00000'),
(23, 'hiah', 'haha', 'haha', 'jka', NULL),
(24, 'hiah', 'haha', 'haha', 'jka', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
