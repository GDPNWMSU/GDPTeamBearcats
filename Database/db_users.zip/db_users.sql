-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2018 at 07:00 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_users`
--
CREATE DATABASE IF NOT EXISTS `db_users` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_users`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstName` varchar(10) NOT NULL,
  `lastName` varchar(10) NOT NULL,
  `resettoken` varchar(200) NOT NULL,
  `TimeofLogin` timestamp(5) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `username`, `password`, `firstName`, `lastName`, `resettoken`, `TimeofLogin`) VALUES
(1, 'abc', '6367c48dd193d56ea7b0baad25b19455e529f5ee', 'Leslie', 'Chandler', '0e4f4d9eea6977906ead6e6c27bf1f3769ac964c', '2018-10-04 09:08:48.55532'),
(2, 'adityamalireddy@gmail.com', '2b743ea5699560665032496d957cd8c0075029d5', 'Aditya', 'Malireddy', 'cdd94494fac8b79df72f2d35f94cfa3b351e0eef', '2018-09-29 09:31:50.00000'),
(3, 'abc@gmail.com', '6367c48dd193d56ea7b0baad25b19455e529f5ee', 'Srikar', 'Karthik', '', '2018-09-28 10:00:00.00000'),
(4, 'pravalikakawali@gmail.com', 'a9993e364706816aba3e25717850c26c9cd0d89d', 'Pravalika', 'kawali', '', '2018-10-04 08:50:33.00000'),
(5, '1lakshmi.konda@gmail.com', 'a9993e364706816aba3e25717850c26c9cd0d89d', 'Sree', 'Lakshmi', '', '2018-09-28 10:00:00.00000'),
(24, 'hiah', 'haha', 'haha', 'jka', '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
