-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2018 at 03:30 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_users`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `role` varchar(10) NOT NULL,
  `resettoken` varchar(200) NOT NULL,
  `TimeofLogin` timestamp(5) NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `email`, `password`, `firstName`, `lastName`, `role`, `resettoken`, `TimeofLogin`) VALUES
(1, 'admin@nwmissouri.edu', '6367c48dd193d56ea7b0baad25b19455e529f5ee', 'Leslie', 'Chandler', 'admin', '0e4f4d9eea6977906ead6e6c27bf1f3769ac964c', '2018-10-04 09:08:48.55532'),
(2, 'adityamalireddy@gmail.com', '2b743ea5699560665032496d957cd8c0075029d5', 'Aditya', 'Malireddy', 'admin', 'cdd94494fac8b79df72f2d35f94cfa3b351e0eef', '2018-09-29 09:31:50.00000'),
(4, 'pravalikakawali@gmail.com', 'a9993e364706816aba3e25717850c26c9cd0d89d', 'Pravalika', 'kawali', 'super user', '', '2018-10-04 08:50:33.00000'),
(5, '1lakshmi.konda@gmail.com', 'a9993e364706816aba3e25717850c26c9cd0d89d', 'Sree', 'Lakshmi', 'super user', '', '2018-09-28 10:00:00.00000'),
(28, 'rajasrikar2010@gmail.com', '5cec175b165e3d5e62c9e13ce848ef6feac81bff', 'Raja Srikar Karthik', 'Chinta', 'admin', '098164a20fc4a2046498ac121794b49bdc5cf2bd', NULL),
(38, 'bharish1993@gmail.com', '5cec175b165e3d5e62c9e13ce848ef6feac81bff', 'Harish', 'Bondalapat', 'super user', '', NULL),
(68, 's530460@nwmissouri.edu', '5cec175b165e3d5e62c9e13ce848ef6feac81bff', 'Raja Srikar Karthik', 'Chinta', 'super user', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_roles`
--

CREATE TABLE `tbl_user_roles` (
  `ID` int(5) NOT NULL,
  `ROLES` varchar(10) NOT NULL,
  `ACCESS` varchar(400) NOT NULL,
  `TIMESTAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_roles`
--

INSERT INTO `tbl_user_roles` (`ID`, `ROLES`, `ACCESS`, `TIMESTAMP`) VALUES
(1, 'admin', '', '2018-10-31 14:09:37'),
(2, 'user', '', '2018-10-31 21:11:42'),
(3, 'super user', '', '2018-10-31 21:12:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_roles`
--
ALTER TABLE `tbl_user_roles`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `tbl_user_roles`
--
ALTER TABLE `tbl_user_roles`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
